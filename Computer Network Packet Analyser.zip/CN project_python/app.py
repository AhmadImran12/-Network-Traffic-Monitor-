from flask import Flask, jsonify, render_template, request, send_file, redirect, url_for, session
from scapy.all import sniff, IP, TCP, UDP, ICMP
import threading
import datetime
import csv
import json
import io
import os
import uuid
from functools import wraps
 
app = Flask(__name__)
app.secret_key = "cn_project_secret_key_2025_xK9#mP"
 
app.config["SESSION_PERMANENT"] = False
 
CREDS_FILE = "users.json"
 
DEFAULT_USERS = {
    "admin": "admin",
}
 
def load_users():
    if os.path.exists(CREDS_FILE):
        with open(CREDS_FILE) as f:
            return json.load(f)
    return dict(DEFAULT_USERS)
 
def save_users(users):
    with open(CREDS_FILE, "w") as f:
        json.dump(users, f)
 
# ─── Server-side active sessions ────────────────────────────────
active_sessions = set()
 
PORT_SERVICES = {
    80:   "HTTP",
    443:  "HTTPS",
    53:   "DNS",
    21:   "FTP",
    22:   "SSH",
    25:   "SMTP",
    110:  "POP3",
    143:  "IMAP",
    3306: "MySQL",
    8080: "HTTP-Alt",
    23:   "Telnet",
    3389: "RDP",
    67:   "DHCP",
    68:   "DHCP",
    123:  "NTP",
    0:    "ICMP"
}
 
# HTTP/HTTPS ports
HTTP_PORTS = {80, 443, 8080}
 
monitoring_active = False
logs = []
sniff_thread = None
packet_count = 0
packets_data = []
 
def get_service(port):
    try:
        return PORT_SERVICES.get(int(port), "Unknown")
    except:
        return "Unknown"
 
def add_log(msg):
    timestamp = datetime.datetime.now().strftime("%H:%M:%S")
    logs.append(f"[{timestamp}] {msg}")
    if len(logs) > 100:
        logs.pop(0)
 
def packet_handler(pkt):
    global packet_count
    if not monitoring_active:
        return
    if not pkt.haslayer(IP):
        return
    try:
        src_ip   = pkt[IP].src
        dst_ip   = pkt[IP].dst
        size     = len(pkt)
        time_now = datetime.datetime.now().strftime("%H:%M:%S")
 
        # ICMP pehle check karo
        if pkt.haslayer(ICMP):
            protocol = "ICMP"
            src_port = 0
            dst_port = 0
        elif pkt.haslayer(TCP):
            protocol = "TCP"
            src_port = pkt[TCP].sport
            dst_port = pkt[TCP].dport
        elif pkt.haslayer(UDP):
            protocol = "UDP"
            src_port = pkt[UDP].sport
            dst_port = pkt[UDP].dport
        else:
            return
 
        service = "ICMP" if protocol == "ICMP" else get_service(dst_port)
 
        packet_count += 1
 
        packets_data.append({
            "No":               packet_count,
            "Time":             time_now,
            "Source IP":        src_ip,
            "Destination IP":   dst_ip,
            "Protocol":         protocol,
            "Packet Size":      size,
            "Source Port":      src_port,
            "Destination Port": dst_port,
            "Service":          service
        })
 
        if packet_count % 10 == 0:
            add_log(f"Captured {packet_count} packets so far...")
 
    except Exception:
        pass
 
def start_sniffing():
    sniff(prn=packet_handler, store=False,
          filter="ip",
          stop_filter=lambda x: not monitoring_active)
 
# ─── Login Required ──────────────────────────────────────────────
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = session.get("token")
        if not session.get("logged_in") or token not in active_sessions:
            session.clear()
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated
 
# ─── Auth Routes ─────────────────────────────────────────────────
 
@app.route("/login", methods=["GET", "POST"])
def login():
    token = session.get("token")
    if session.get("logged_in") and token in active_sessions:
        return redirect(url_for("index"))
 
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        users = load_users()
        if username in users and users[username] == password:
            new_token = str(uuid.uuid4())
            active_sessions.add(new_token)
            session.clear()
            session["logged_in"] = True
            session["username"]  = username
            session["token"]     = new_token
            add_log(f"{username} logged in.")
            return redirect(url_for("index"))
        else:
            return redirect(url_for("login") + "?err=1")
 
    return render_template("login.html")
 
 
@app.route("/logout")
def logout():
    username = session.get("username", "User")
    token = session.get("token")
    if token in active_sessions:
        active_sessions.discard(token)
    add_log(f"{username} logged out.")
    session.clear()
    return redirect(url_for("login"))
 
 
# ─── Main App Routes ──────────────────────────────────────────────
 
@app.route("/")
@login_required
def index():
    return render_template("index.html", username=session.get("username", "User"))
 
@app.route("/start", methods=["POST"])
@login_required
def start_monitoring():
    global monitoring_active, logs, sniff_thread, packet_count, packets_data
    if monitoring_active:
        return jsonify({"status": "already running"})
    monitoring_active = True
    packet_count = 0
    logs.clear()
    packets_data.clear()
    add_log(f"Monitoring started by {session.get('username', 'User')}.")
    sniff_thread = threading.Thread(target=start_sniffing, daemon=True)
    sniff_thread.start()
    return jsonify({"status": "started"})
 
@app.route("/stop", methods=["POST"])
@login_required
def stop_monitoring():
    global monitoring_active
    monitoring_active = False
    add_log(f"Monitoring stopped. Total packets captured: {packet_count}")
    return jsonify({"status": "stopped"})
 
@app.route("/clear", methods=["POST"])
@login_required
def clear_data():
    global packet_count, logs, packets_data
    packet_count = 0
    packets_data.clear()
    logs.clear()
    return jsonify({"status": "cleared"})
 
@app.route("/download")
@login_required
def download_csv():
    output = io.StringIO()
    fieldnames = [
        "No", "Time", "Source IP", "Destination IP",
        "Protocol", "Packet Size", "Source Port",
        "Destination Port", "Service"
    ]
    writer = csv.DictWriter(output, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(packets_data)
    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode("utf-8")),
        as_attachment=True,
        download_name="captured_packets.csv",
        mimetype="text/csv"
    )
 
@app.route("/data")
@login_required
def get_data():
    protocol = request.args.get("protocol", "").strip().upper()
    src_ip   = request.args.get("src_ip",   "").strip()
    dst_ip   = request.args.get("dst_ip",   "").strip()
    service  = request.args.get("service",  "").strip()
 
    packets = list(packets_data)
    total_captured = len(packets)
 
    if protocol:
        packets = [p for p in packets if p["Protocol"].upper() == protocol]
    if src_ip:
        packets = [p for p in packets if src_ip in p["Source IP"]]
    if dst_ip:
        packets = [p for p in packets if dst_ip in p["Destination IP"]]
    if service:
        packets = [p for p in packets if p["Service"].lower() == service.lower()]
 
    total_filtered = len(packets)
    packets = packets[-500:]
 
    return jsonify({
        "packets":        packets,
        "total_captured": total_captured,
        "total_filtered": total_filtered,
        "logs":           logs
    })
 
@app.route("/stats")
@login_required
def get_stats():
    packets = list(packets_data)
 
    total      = len(packets)
    tcp_count  = sum(1 for p in packets if p["Protocol"] == "TCP")
    udp_count  = sum(1 for p in packets if p["Protocol"] == "UDP")
    icmp_count = sum(1 for p in packets if p["Protocol"] == "ICMP")
 
    # HTTP/HTTPS: sirf port 80, 443, 8080 wale TCP packets count karo (protocol based)
    http_count = sum(
        1 for p in packets
        if p["Protocol"] == "TCP" and (
            int(p.get("Destination Port", 0)) in HTTP_PORTS or
            int(p.get("Source Port", 0)) in HTTP_PORTS
        )
    )
 
    sizes = []
    for p in packets:
        try:
            sizes.append(int(p["Packet Size"]))
        except:
            pass
 
    avg_size = round(sum(sizes) / len(sizes), 2) if sizes else 0
    max_size = max(sizes) if sizes else 0
    min_size = min(sizes) if sizes else 0
 
    src_count = {}
    for p in packets:
        ip = p["Source IP"]
        src_count[ip] = src_count.get(ip, 0) + 1
    top_src = sorted(src_count.items(), key=lambda x: x[1], reverse=True)[:5]
 
    svc_count = {}
    for p in packets:
        svc = p["Service"]
        svc_count[svc] = svc_count.get(svc, 0) + 1
 
    return jsonify({
        "total_packets":   total,
        "tcp":             tcp_count,
        "udp":             udp_count,
        "icmp":            icmp_count,
        "http":            http_count,
        "avg_packet_size": avg_size,
        "max_size":        max_size,
        "min_size":        min_size,
        "top_sources":     top_src,
        "services":        svc_count
    })
 
if __name__ == "__main__":
    app.run(debug=False, threaded=True)